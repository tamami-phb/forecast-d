--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.18
-- Dumped by pg_dump version 10.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.fakta DROP CONSTRAINT fk_waktu;
ALTER TABLE ONLY public.fakta DROP CONSTRAINT fakta_pkey;
ALTER TABLE ONLY public.dim_waktu DROP CONSTRAINT dim_waktu_pkey;
ALTER TABLE ONLY public.dim_staf DROP CONSTRAINT dim_staf_pkey;
ALTER TABLE ONLY public.dim_film DROP CONSTRAINT dim_film_pkey;
ALTER TABLE ONLY public.dim_customer DROP CONSTRAINT dim_customer_pkey;
DROP TABLE public.fakta;
DROP TABLE public.dim_waktu;
DROP TABLE public.dim_staf;
DROP TABLE public.dim_film;
DROP TABLE public.dim_customer;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pytlnshqyoqjwn;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dim_customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_customer (
    id integer NOT NULL,
    nama character varying(250),
    city character varying(250),
    country character varying(250),
    customer_id integer
);


ALTER TABLE public.dim_customer OWNER TO pytlnshqyoqjwn;

--
-- Name: dim_film; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_film (
    id integer NOT NULL,
    title character varying(250),
    rating character varying(250),
    category character varying(250),
    film_id integer
);


ALTER TABLE public.dim_film OWNER TO pytlnshqyoqjwn;

--
-- Name: dim_staf; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_staf (
    id integer NOT NULL,
    nama character varying(250),
    manager character varying(250),
    country character varying(250),
    staf_id integer
);


ALTER TABLE public.dim_staf OWNER TO pytlnshqyoqjwn;

--
-- Name: dim_waktu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_waktu (
    id integer NOT NULL,
    tanggal integer,
    bulan character varying(20),
    tahun integer
);


ALTER TABLE public.dim_waktu OWNER TO pytlnshqyoqjwn;

--
-- Name: fakta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fakta (
    id integer NOT NULL,
    amount numeric,
    sk_waktu integer,
    sk_film integer,
    sk_customer integer,
    sk_staf integer
);


ALTER TABLE public.fakta OWNER TO pytlnshqyoqjwn;

--
-- Data for Name: dim_customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_customer (id, nama, city, country, customer_id) FROM stdin;
\.
COPY public.dim_customer (id, nama, city, country, customer_id) FROM '$$PATH$$/2823.dat';

--
-- Data for Name: dim_film; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_film (id, title, rating, category, film_id) FROM stdin;
\.
COPY public.dim_film (id, title, rating, category, film_id) FROM '$$PATH$$/2822.dat';

--
-- Data for Name: dim_staf; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_staf (id, nama, manager, country, staf_id) FROM stdin;
\.
COPY public.dim_staf (id, nama, manager, country, staf_id) FROM '$$PATH$$/2821.dat';

--
-- Data for Name: dim_waktu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_waktu (id, tanggal, bulan, tahun) FROM stdin;
\.
COPY public.dim_waktu (id, tanggal, bulan, tahun) FROM '$$PATH$$/2820.dat';

--
-- Data for Name: fakta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fakta (id, amount, sk_waktu, sk_film, sk_customer, sk_staf) FROM stdin;
\.
COPY public.fakta (id, amount, sk_waktu, sk_film, sk_customer, sk_staf) FROM '$$PATH$$/2824.dat';

--
-- Name: dim_customer dim_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_customer
    ADD CONSTRAINT dim_customer_pkey PRIMARY KEY (id);


--
-- Name: dim_film dim_film_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_film
    ADD CONSTRAINT dim_film_pkey PRIMARY KEY (id);


--
-- Name: dim_staf dim_staf_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_staf
    ADD CONSTRAINT dim_staf_pkey PRIMARY KEY (id);


--
-- Name: dim_waktu dim_waktu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_waktu
    ADD CONSTRAINT dim_waktu_pkey PRIMARY KEY (id);


--
-- Name: fakta fakta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fakta
    ADD CONSTRAINT fakta_pkey PRIMARY KEY (id);


--
-- Name: fakta fk_waktu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fakta
    ADD CONSTRAINT fk_waktu FOREIGN KEY (sk_waktu) REFERENCES public.dim_waktu(id);


--
-- PostgreSQL database dump complete
--

